import React from 'react';
import { Link } from 'react-router-dom';
import { WEDDING_DATA } from '../constants';
import { MapPin, Calendar, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="relative h-screen min-h-[600px] flex items-center justify-center text-center px-4 overflow-hidden">
        {/* Background Image with Overlay */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat bg-fixed"
          style={{ 
            backgroundImage: 'url("https://images.unsplash.com/photo-1570168007204-dfb528c6958f?q=80&w=2535&auto=format&fit=crop")',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 text-white animate-fade-in-up">
          <p className="font-sans text-sm md:text-base tracking-[0.3em] uppercase mb-4 text-wedding-gold font-bold">
            Celebrate with us
          </p>
          <h1 className="font-serif text-5xl md:text-7xl lg:text-9xl mb-6 leading-tight drop-shadow-lg">
            {WEDDING_DATA.couple.partner1} <br /> 
            <span className="text-wedding-gold italic text-4xl md:text-6xl">&</span> <br />
            {WEDDING_DATA.couple.partner2}
          </h1>
          
          <div className="flex flex-col md:flex-row justify-center items-center gap-4 md:gap-8 font-sans text-lg md:text-xl tracking-wide font-medium">
            <div className="flex items-center gap-2">
              <Calendar size={24} className="text-wedding-gold" />
              <span>{WEDDING_DATA.date}</span>
            </div>
            <div className="hidden md:block w-px h-8 bg-wedding-gold"></div>
            <div className="flex items-center gap-2">
              <MapPin size={24} className="text-wedding-gold" />
              <span>{WEDDING_DATA.location.city}</span>
            </div>
          </div>

          <div className="mt-16">
            <Link 
              to="/events" 
              className="inline-block bg-wedding-rani hover:bg-pink-700 text-white font-sans uppercase tracking-widest text-sm py-4 px-12 rounded-full transition-all duration-300 hover:tracking-[0.2em] shadow-lg border-2 border-transparent hover:border-wedding-gold"
            >
              View Events
            </Link>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-white/90">
          <span className="block text-[10px] uppercase tracking-widest mb-2 text-wedding-gold">Scroll</span>
          <div className="w-px h-12 bg-wedding-gold mx-auto"></div>
        </div>
      </div>

      {/* Intro / Quote Section */}
      <section className="py-24 px-4 bg-wedding-cream relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-wedding-marigold/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-wedding-rani/10 rounded-full blur-3xl translate-x-1/4 translate-y-1/4"></div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="font-serif text-3xl md:text-5xl text-wedding-charcoal mb-8 leading-snug">
            "I may not have gone where I intended to go, but I think I have ended up where I needed to be."
          </h2>
          <p className="font-sans text-wedding-rani uppercase tracking-widest text-xs font-bold mb-8">
             Douglas Adams
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-wedding-rani to-wedding-marigold mx-auto mb-8"></div>
          
          <div className="mt-8">
             <Link to="/story" className="text-wedding-rani font-bold uppercase tracking-widest text-xs hover:text-wedding-marigold transition-colors inline-flex items-center gap-2 border-b-2 border-wedding-rani pb-1">
               Read Our Story <ArrowRight size={16} />
             </Link>
          </div>
        </div>
      </section>

      {/* Traditions Full Width Section */}
      <section className="w-full h-96 md:h-[600px] relative group overflow-hidden">
         <img src="https://images.unsplash.com/photo-1597157639073-69284dc0fdaf?q=80&w=1174&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Traditions" className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" />
         <Link to="/traditions" className="absolute inset-0 bg-wedding-green/80 opacity-0 group-hover:opacity-90 transition-opacity flex items-center justify-center">
            <span className="text-white font-serif text-4xl tracking-wide border-2 border-white px-8 py-4">Traditions</span>
         </Link>
         <div className="absolute bottom-0 left-0 p-6 bg-gradient-to-t from-black/80 to-transparent w-full md:hidden">
            <span className="text-white font-serif text-2xl">Traditions</span>
         </div>
      </section>
    </div>
  );
};

export default Home;