import React from 'react';

const Story: React.FC = () => {
  return (
    <div className="min-h-screen bg-wedding-pattern pt-24 pb-20 overflow-hidden relative">
      
      {/* Decorative background blobs */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-wedding-marigold/15 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-wedding-rani/15 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="max-w-5xl mx-auto px-4 relative z-10">
        
        {/* Simplified Header */}
        <div className="text-center mb-16 animate-fade-in-up">
           <p className="text-wedding-rani text-sm tracking-widest uppercase mb-2 font-bold">How We Met</p>
           <h1 className="font-serif text-6xl text-wedding-charcoal mb-12">Our Journey</h1>
           
           {/* Big Picture */}
           <div className="relative rounded-xl overflow-hidden shadow-xl border-4 border-white mx-auto max-w-4xl">
             <img 
               src="https://lh3.googleusercontent.com/pw/AP1GczO1xDfNPI3ZJkGHdniIfQKvv9U2hBSBAwRjD-UdjmTpXE3SEsZnammzDWAutk-kbAJ0LK-1tpDHGVloUvvu50pd7gcqAzuMgRpqYtlgfWVVQsYzRgN2_nP1WvdfZCjhKwRixb2bXITrTqZ8hJv0K6rLJA=w1307-h872-s-no-gm?authuser=0" 
               alt="Pavitra and Ramon" 
               className="w-full h-auto object-cover"
             />
           </div>
        </div>

        {/* Timeline */}
        <div className="relative border-l-2 border-wedding-gold ml-4 md:ml-1/2 space-y-16 animate-fade-in-up">
          <div className="relative pl-8 md:pl-0">
             <div className="absolute -left-[9px] top-2 w-4 h-4 bg-wedding-rani rounded-full ring-4 ring-wedding-cream"></div>
             <div className="md:w-1/2 md:pr-16 md:ml-auto md:text-left group">
                <span className="text-wedding-marigold font-bold text-sm uppercase tracking-widest bg-white px-2 rounded shadow-sm">Feb 2022</span>
                <div className="bg-white/80 p-6 mt-4 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-white flex flex-col items-center sm:flex-row sm:items-center gap-6">
                  <img src="https://github.com/rf0513/wedding-site/blob/main/tram.jpeg?raw=true" alt="Metamates" className="w-60 h-60 object-cover rounded-lg shadow-sm flex-shrink-0 bg-gray-200" />
                  <div>
                    <h3 className="font-serif text-3xl text-wedding-charcoal mb-2">Metamates</h3>
                    <p className="text-gray-600 font-light">Pavi and Ramon met at work in Albuquerque, as simple co-workers who quickly became inseparable.</p>
                  </div>
                </div>
             </div>
          </div>

          <div className="relative pl-8 md:pl-0">
             <div className="absolute -left-[9px] top-2 w-4 h-4 bg-wedding-green rounded-full ring-4 ring-wedding-cream"></div>
             <div className="md:w-1/2 md:pr-16 md:mr-auto md:text-right md:-ml-[50%] group">
                <span className="text-wedding-marigold font-bold text-sm uppercase tracking-widest bg-white px-2 rounded shadow-sm">May 2022</span>
                <div className="bg-white/80 p-6 mt-4 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-white flex flex-col items-center sm:flex-row-reverse sm:items-center gap-6">
                  <img src="https://github.com/rf0513/wedding-site/blob/main/rockies.jpeg?raw=true" alt="Rocky Mountains" className="w-60 h-60 object-cover rounded-lg shadow-sm flex-shrink-0 bg-gray-200" />
                  <div>
                    <h3 className="font-serif text-3xl text-wedding-charcoal mb-2">Rocky Mountains</h3>
                    <p className="text-gray-600 font-light">They began dating after a spontanous trip to Rocky Mountains National Park in Colorado over Memorial Day.</p>
                  </div>
                </div>
             </div>
          </div>

          <div className="relative pl-8 md:pl-0">
             <div className="absolute -left-[9px] top-2 w-4 h-4 bg-wedding-green rounded-full ring-4 ring-wedding-cream"></div>
             <div className="md:w-1/2 md:pr-16 md:mr-auto md:text-right md:-ml-[50%] group">
                <span className="text-wedding-marigold font-bold text-sm uppercase tracking-widest bg-white px-2 rounded shadow-sm">Dec 2023</span>
                <div className="bg-white/80 p-6 mt-4 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-white flex flex-col items-center sm:flex-row-reverse sm:items-center gap-6">
                  <img src="https://github.com/rf0513/wedding-site/blob/main/mackinac.jpeg?raw=true" alt="Bay Area" className="w-60 h-60 object-cover rounded-lg shadow-sm flex-shrink-0 bg-gray-200" />
                  <div>
                    <h3 className="font-serif text-3xl text-wedding-charcoal mb-2">Bay Area</h3>
                    <p className="text-gray-600 font-light">Pavi relocated for a new job, and Ramon was not very far behind to begin their California chapter.</p>
                  </div>
                </div>
             </div>
          </div>


          <div className="relative pl-8 md:pl-0">
             <div className="absolute -left-[9px] top-2 w-4 h-4 bg-wedding-rani rounded-full ring-4 ring-wedding-cream"></div>
             <div className="md:w-1/2 md:pr-16 md:ml-auto md:text-left group">
                <span className="text-wedding-marigold font-bold text-sm uppercase tracking-widest bg-white px-2 rounded shadow-sm">Oct 12, 2025</span>
                <div className="bg-white/80 p-6 mt-4 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-white flex flex-col items-center sm:flex-row sm:items-center gap-6">
                  <img src="https://github.com/rf0513/wedding-site/blob/main/proposal.jpg?raw=true" alt="The Proposal" className="w-60 h-60 object-cover rounded-lg shadow-sm flex-shrink-0 bg-gray-200" />
                  <div>
                    <h3 className="font-serif text-3xl text-wedding-charcoal mb-2">The Proposal</h3>
                    <p className="text-gray-600 font-light">Sunset at Slacker's Hill. A diamond ring and the city skyline as our witness.</p>
                  </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Story;