import React, { useState } from 'react';
import { RSVPFormData } from '../types';
import { Send, CheckCircle, Sparkles } from 'lucide-react';

const RSVP: React.FC = () => {
  const [formData, setFormData] = useState<RSVPFormData>({
    firstName: '',
    lastName: '',
    email: '',
    attending: 'yes',
    guests: 0,
    dietaryRestrictions: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    console.log('RSVP Submitted:', formData);
    setTimeout(() => {
      setSubmitted(true);
    }, 1000);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-wedding-pattern pt-32 pb-20 px-4 flex items-center justify-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-wedding-marigold/10 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-wedding-rani/10 rounded-full blur-[100px] pointer-events-none"></div>
        
        <div className="max-w-lg w-full bg-white/95 backdrop-blur-sm p-12 shadow-2xl text-center rounded-2xl border-t-8 border-wedding-rani animate-fade-in-up relative z-10">
          <div className="w-20 h-20 bg-wedding-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
             <CheckCircle size={48} className="text-wedding-green" />
          </div>
          <h2 className="font-serif text-4xl text-wedding-charcoal mb-4">Dhanyavad!</h2>
          <p className="text-gray-600 font-light mb-8">
            Your response has been recorded. We are counting down the days to see you in Mumbai!
          </p>
          <button 
            onClick={() => setSubmitted(false)}
            className="text-wedding-rani font-bold underline hover:text-pink-700 transition-colors text-sm uppercase tracking-widest"
          >
            Submit another response
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-wedding-pattern pt-32 pb-20 px-4 relative overflow-hidden">
      {/* Decorative Blobs */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-wedding-marigold/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-wedding-rani/10 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="max-w-2xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden border border-gray-100 relative z-10">
        <div className="bg-wedding-rani p-10 text-center text-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-black/10"></div>
          <Sparkles className="absolute top-4 right-4 text-wedding-gold opacity-50" size={32} />
          <div className="relative z-10">
            <p className="uppercase tracking-[0.2em] text-sm font-bold mb-2 text-wedding-gold">Kindly Respond By</p>
            <h2 className="font-serif text-4xl font-bold">December 15, 2026</h2>
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 md:p-12 space-y-8 bg-white/95 backdrop-blur-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label htmlFor="firstName" className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">First Name</label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                required
                value={formData.firstName}
                onChange={handleChange}
                className="w-full border-b-2 border-gray-200 py-2 focus:border-wedding-rani outline-none transition-colors bg-transparent font-serif text-lg"
                placeholder="Priya"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="lastName" className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">Last Name</label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                required
                value={formData.lastName}
                onChange={handleChange}
                className="w-full border-b-2 border-gray-200 py-2 focus:border-wedding-rani outline-none transition-colors bg-transparent font-serif text-lg"
                placeholder="Sharma"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="email" className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              required
              value={formData.email}
              onChange={handleChange}
              className="w-full border-b-2 border-gray-200 py-2 focus:border-wedding-rani outline-none transition-colors bg-transparent font-serif text-lg"
              placeholder="priya@example.com"
            />
          </div>

          <div className="space-y-4">
            <span className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">Will you be attending?</span>
            <div className="flex gap-8">
              <label className="flex items-center gap-3 cursor-pointer group">
                <input
                  type="radio"
                  name="attending"
                  value="yes"
                  checked={formData.attending === 'yes'}
                  onChange={handleChange}
                  className="w-5 h-5 text-wedding-rani focus:ring-wedding-rani accent-wedding-rani"
                />
                <span className="font-serif text-xl text-gray-700 group-hover:text-wedding-rani transition-colors">Yes, happily!</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer group">
                <input
                  type="radio"
                  name="attending"
                  value="no"
                  checked={formData.attending === 'no'}
                  onChange={handleChange}
                  className="w-5 h-5 text-wedding-rani focus:ring-wedding-rani accent-wedding-rani"
                />
                <span className="font-serif text-xl text-gray-700 group-hover:text-wedding-rani transition-colors">Regretfully no</span>
              </label>
            </div>
          </div>

          {formData.attending === 'yes' && (
            <div className="space-y-8 animate-fade-in-up">
              <div className="space-y-2">
                <label htmlFor="guests" className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">Total Guests</label>
                <select
                  id="guests"
                  name="guests"
                  value={formData.guests}
                  onChange={handleChange}
                  className="w-full border-b-2 border-gray-200 py-2 focus:border-wedding-rani outline-none bg-transparent font-serif text-lg"
                >
                  <option value="1">1 (Just me)</option>
                  <option value="2">2 (Me + Plus One)</option>
                  <option value="3">3 (Family of 3)</option>
                  <option value="4">4 (Family of 4)</option>
                </select>
              </div>

              <div className="space-y-2">
                <label htmlFor="dietaryRestrictions" className="block text-xs font-bold uppercase tracking-widest text-wedding-marigold">Dietary Requirements</label>
                <textarea
                  id="dietaryRestrictions"
                  name="dietaryRestrictions"
                  rows={2}
                  value={formData.dietaryRestrictions}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-200 rounded-lg p-3 focus:border-wedding-rani outline-none transition-colors"
                  placeholder="Vegetarian, Jain, Allergies..."
                />
              </div>
            </div>
          )}

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-wedding-charcoal text-white py-4 font-sans uppercase tracking-widest text-sm hover:bg-black transition-colors flex items-center justify-center gap-2 rounded-full shadow-lg"
            >
              Send RSVP <Send size={16} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RSVP;