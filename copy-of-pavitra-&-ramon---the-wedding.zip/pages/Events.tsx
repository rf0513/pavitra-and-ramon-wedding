import React from 'react';
import { EVENTS } from '../constants';
import { MapPin, Clock, Music, Heart, Utensils } from 'lucide-react';

const Events: React.FC = () => {
  const getIcon = (name: string) => {
      switch(name) {
          case 'party': return <Music size={40} className="text-wedding-marigold" />;
          case 'ring': return <Heart size={40} className="text-wedding-rani" />;
          case 'cheers': return <Utensils size={40} className="text-wedding-green" />;
          default: return <Clock size={40} className="text-wedding-gold" />;
      }
  }

  return (
    <div className="min-h-screen pt-24 pb-20 bg-wedding-pattern relative overflow-hidden">
      {/* Decorative Blobs */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-wedding-marigold/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-wedding-rani/10 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/3 pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in-up">
          <p className="text-wedding-rani text-sm tracking-widest uppercase mb-2 font-bold">The Celebration</p>
          <h1 className="font-serif text-6xl text-wedding-charcoal mb-6">Wedding Events</h1>
          <p className="text-gray-600 font-light max-w-lg mx-auto">
            Join us for a vibrant celebration of love in the heart of Mumbai.
          </p>
        </div>

        <div className="space-y-8">
          {EVENTS.map((event, index) => (
            <div 
              key={event.id}
              className="bg-white/90 backdrop-blur-sm p-8 md:p-10 rounded-xl shadow-md border-l-8 border-wedding-rani flex flex-col md:flex-row gap-6 md:gap-10 items-start md:items-center hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 group"
            >
              {/* Time Column */}
              <div className="flex-shrink-0 w-full md:w-32 text-center md:text-right border-b md:border-b-0 md:border-r border-gray-100 pb-4 md:pb-0 md:pr-6">
                 <span className="block font-serif text-3xl text-wedding-marigold mb-1 font-bold group-hover:text-wedding-rani transition-colors">{event.time}</span>
                 <span className="text-xs uppercase tracking-wider text-gray-400 font-bold">{event.date}</span>
              </div>

              {/* Details Column */}
              <div className="flex-grow">
                <h3 className="font-serif text-3xl text-wedding-charcoal mb-2">{event.title}</h3>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 text-sm text-gray-500 mb-4 font-medium">
                  <div className="flex items-center gap-1 text-wedding-green">
                    <MapPin size={18} />
                    {event.location}
                  </div>
                  <div className="hidden sm:block text-gray-300">•</div>
                  <div className="flex items-center gap-1">
                     <span className="italic">{event.address}</span>
                  </div>
                </div>
                <p className="text-gray-600 leading-relaxed">
                  {event.description}
                </p>
              </div>

              {/* Icon */}
              <div className="hidden lg:block bg-wedding-cream p-4 rounded-full group-hover:bg-wedding-gold/20 transition-colors">
                 {getIcon(event.iconName)}
              </div>
            </div>
          ))}
        </div>

        {/* Map Section */}
        <div className="mt-16 bg-white/90 backdrop-blur-sm p-8 rounded-xl text-center shadow-lg border border-wedding-marigold/20">
          <h3 className="font-serif text-3xl text-wedding-charcoal mb-4">Accommodation</h3>
          <p className="text-gray-600 mb-6">
            We have secured a room block at <strong>Taj The Trees, Mumbai</strong>. <br/> Please mention the "Pavitra & Ramon" wedding when booking for a special rate.
          </p>
          <a 
            href="https://maps.google.com/?q=Taj+The+Trees+Mumbai" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-white bg-wedding-green hover:bg-green-700 px-6 py-3 rounded-full font-bold uppercase text-xs tracking-widest transition-all shadow-md"
          >
            Get Directions <MapPin size={14} />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Events;