import React, { useState } from 'react';
import { WEDDING_CUSTOMS, ATTIRE_GUIDE } from '../constants';
import { Info, Sparkles, Shirt } from 'lucide-react';

const Traditions: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ceremonies' | 'attire'>('ceremonies');

  return (
    <div className="min-h-screen pt-24 pb-20 bg-wedding-pattern relative overflow-hidden">
      {/* Decorative Blobs */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-wedding-marigold/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-wedding-rani/10 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/3 pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-10 animate-fade-in-up">
          <p className="text-wedding-rani text-sm tracking-widest uppercase mb-2 font-bold">For Our Guests</p>
          <h1 className="font-serif text-5xl md:text-6xl text-wedding-charcoal mb-6">A Guide to Indian Traditions</h1>
          <p className="text-gray-600 font-light max-w-2xl mx-auto leading-relaxed text-lg">
            We are so excited to welcome our family and friends from Panama and the US to Mumbai! 
            We know Indian weddings can be complex, so we've put together this guide to help you 
            navigate the ceremonies and the wardrobe.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-16 animate-fade-in-up">
           <div className="bg-white/80 backdrop-blur rounded-full p-1 shadow-md inline-flex border border-wedding-gold/30">
              <button 
                onClick={() => setActiveTab('ceremonies')}
                className={`px-8 py-3 rounded-full text-sm font-bold uppercase tracking-widest transition-all ${
                  activeTab === 'ceremonies' 
                    ? 'bg-wedding-rani text-white shadow-md' 
                    : 'text-gray-500 hover:text-wedding-charcoal'
                }`}
              >
                The Ceremonies
              </button>
              <button 
                onClick={() => setActiveTab('attire')}
                className={`px-8 py-3 rounded-full text-sm font-bold uppercase tracking-widest transition-all ${
                  activeTab === 'attire' 
                    ? 'bg-wedding-rani text-white shadow-md' 
                    : 'text-gray-500 hover:text-wedding-charcoal'
                }`}
              >
                Attire Guide
              </button>
           </div>
        </div>

        {/* Ceremonies Content */}
        {activeTab === 'ceremonies' && (
          <div className="space-y-16 animate-fade-in-up">
            {WEDDING_CUSTOMS.map((custom, index) => (
              <div 
                key={custom.id} 
                className={`flex flex-col md:flex-row gap-8 md:gap-16 items-center ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}
              >
                {/* Image Section */}
                <div className="w-full md:w-1/2 relative group">
                  <div className="absolute inset-0 bg-wedding-gold/20 transform rotate-3 rounded-2xl transition-transform group-hover:rotate-6"></div>
                  <div className="relative overflow-hidden rounded-2xl shadow-xl aspect-video">
                    <img 
                      src={custom.imageUrl} 
                      alt={custom.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent md:hidden flex items-end p-6">
                      <h3 className="text-white font-serif text-3xl">{custom.title}</h3>
                    </div>
                  </div>
                </div>

                {/* Text Content */}
                <div className="w-full md:w-1/2 space-y-6">
                  <div>
                    <span className="text-wedding-marigold font-bold text-xs uppercase tracking-widest mb-1 block">
                      {custom.marathiTitle}
                    </span>
                    <h2 className="text-4xl font-serif text-wedding-charcoal mb-4">{custom.title}</h2>
                    <div className="w-16 h-1 bg-wedding-rani mb-6"></div>
                  </div>

                  <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl border-l-4 border-wedding-rani shadow-sm">
                    <div className="flex items-start gap-3 mb-2">
                        <Info className="text-wedding-rani mt-1 flex-shrink-0" size={20} />
                        <div>
                          <h4 className="font-bold text-wedding-charcoal text-sm uppercase tracking-wide mb-1">Significance</h4>
                          <p className="text-gray-600 font-light leading-relaxed">{custom.significance}</p>
                        </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="bg-white/90 backdrop-blur-sm p-5 rounded-xl border border-wedding-gold/30 shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex items-center gap-2 mb-3">
                              <div className="bg-wedding-gold/20 p-2 rounded-full">
                                  <Shirt className="text-wedding-marigold" size={18} />
                              </div>
                              <h4 className="font-bold text-wedding-charcoal text-sm uppercase">What to Wear</h4>
                          </div>
                          <p className="text-gray-600 text-sm font-light leading-relaxed">{custom.whatToWear}</p>
                          <button onClick={() => setActiveTab('attire')} className="text-xs text-wedding-rani underline mt-2 font-bold uppercase tracking-wider">See Examples</button>
                      </div>

                      <div className="bg-white/90 backdrop-blur-sm p-5 rounded-xl border border-wedding-gold/30 shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex items-center gap-2 mb-3">
                              <div className="bg-wedding-gold/20 p-2 rounded-full">
                                  <Sparkles className="text-wedding-marigold" size={18} />
                              </div>
                              <h4 className="font-bold text-wedding-charcoal text-sm uppercase">What to Expect</h4>
                          </div>
                          <p className="text-gray-600 text-sm font-light leading-relaxed">{custom.whatToExpect}</p>
                      </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Attire Guide Content */}
        {activeTab === 'attire' && (
          <div className="animate-fade-in-up">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               {ATTIRE_GUIDE.map((item) => (
                 <div key={item.id} className="bg-white/95 backdrop-blur-sm rounded-2xl overflow-hidden shadow-lg border border-gray-100 group hover:shadow-2xl transition-all duration-300">
                    {/* Changed h-64 to aspect-[3/4] and added object-top for better display of outfits */}
                    <div className="relative aspect-[3/4] overflow-hidden">
                       <img 
                        src={item.imageUrl} 
                        alt={item.name} 
                        className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                       />
                       <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-wedding-charcoal shadow-sm">
                          {item.gender}
                       </div>
                    </div>
                    <div className="p-8">
                       <div className="mb-4">
                         <h3 className="font-serif text-3xl text-wedding-charcoal mb-1">{item.name}</h3>
                         {item.pronunciation && (
                           <span className="text-wedding-marigold text-sm font-light italic">({item.pronunciation})</span>
                         )}
                       </div>
                       
                       <p className="text-gray-600 font-light leading-relaxed mb-6 h-auto md:h-24">
                         {item.description}
                       </p>
                       
                       <div className="border-t border-gray-100 pt-4">
                          <span className="text-xs font-bold uppercase tracking-widest text-wedding-rani block mb-2">Perfect For</span>
                          <div className="flex flex-wrap gap-2">
                             {item.bestFor.map(event => (
                               <span key={event} className="bg-wedding-cream text-wedding-charcoal text-xs px-2 py-1 rounded border border-wedding-gold/30">
                                 {event}
                               </span>
                             ))}
                          </div>
                       </div>
                    </div>
                 </div>
               ))}
            </div>
            <div className="mt-12 text-center bg-white/50 backdrop-blur p-8 rounded-xl border-2 border-dashed border-wedding-gold/50">
               <h4 className="font-serif text-2xl text-wedding-charcoal mb-2">Where to Buy?</h4>
               <p className="text-gray-600 font-light">
                 We recommend checking out <strong>Pernia's Pop-Up Shop</strong>, <strong>Manyavar</strong> (for men), or <strong>Kalki Fashion</strong> online. 
                 If you are arriving in Mumbai early, we'd love to take you shopping at Santa Cruz Market!
               </p>
            </div>
          </div>
        )}
        
        {/* Footer Note */}
        <div className="mt-20 text-center bg-white/50 backdrop-blur-md p-8 rounded-2xl border border-wedding-rani/20">
           <h3 className="font-serif text-2xl text-wedding-charcoal mb-2">Still have questions?</h3>
           <p className="text-gray-600 font-light mb-4">
             Don't worry about getting everything perfect. The most important thing is your presence! 
           </p>
           <p className="text-wedding-rani font-bold">
             Ask our Wedding Assistant chatbot (bottom right) for more tips!
           </p>
        </div>

      </div>
    </div>
  );
};

export default Traditions;