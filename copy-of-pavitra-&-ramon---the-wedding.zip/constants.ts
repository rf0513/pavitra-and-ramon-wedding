import { WeddingEvent, RegistryItem, WeddingCustom, AttireItem } from './types';

export const WEDDING_DATA = {
  couple: {
    partner1: "Pavitra Kanse",
    partner2: "Ramon Feliu",
    hashtag: "#PR27"
  },
  date: "February 2nd - 4th, 2027",
  location: {
    city: "Mumbai, India",
    venue: "Taj The Trees"
  },
  story: ``,
  travelInfo: "Fly into Chhatrapati Shivaji Maharaj International Airport (BOM). We recommend staying at Taj The Trees, Mumbai. Ubers and local taxis are readily available."
};

export const EVENTS: WeddingEvent[] = [
  {
    id: '1',
    title: 'Haldi & Mehendi',
    date: 'Feb 02',
    time: '11:00 AM',
    location: 'Taj The Trees',
    address: 'Pirojshanagar, Vikhroli, Mumbai',
    description: 'A colorful day of turmeric, henna, and music to kick off the festivities. Dress code: Bright Yellows and Oranges.',
    iconName: 'party'
  },
  {
    id: '2',
    title: 'Vows & Sangeet',
    date: 'Feb 03',
    time: '5:00 PM',
    location: 'Taj The Trees',
    address: 'Pirojshanagar, Vikhroli, Mumbai',
    description: 'We exchange our vows followed by a musical evening of dance and celebration. Dress code: Glamorous / Sangeet style.',
    iconName: 'cheers'
  },
  {
    id: '3',
    title: 'Wedding & Reception',
    date: 'Feb 04',
    time: '4:30 PM',
    location: 'Taj The Trees',
    address: 'Pirojshanagar, Vikhroli, Mumbai',
    description: 'The traditional Maharashtrian wedding ceremony followed by a grand reception dinner.',
    iconName: 'ring'
  }
];

export const REGISTRY_ITEMS: RegistryItem[] = [
  {
    id: 'charity',
    store: 'Educate Girls',
    link: 'https://www.educategirls.org/',
    description: 'We support Educate Girls, one of the most rigorously measured and impactful education charities in India. Your donation empowers communities.',
    imageUrl: 'https://www.educategirls.ngo/wp-content/uploads/2024/10/Educate-Girls-6.jpg'
  },
  {
    id: 'btc',
    store: 'Bitcoin Fund',
    link: 'bc1qh0z7g3ttt5mx4ey0a0qxx2l6qj8pl5xg6cx35d',
    description: 'We gratefully accept Bitcoin contributions to start our life together.',
    imageUrl: 'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?auto=format&fit=crop&q=80&w=800'
  }
];

export const WEDDING_CUSTOMS: WeddingCustom[] = [
  {
    id: 'haldi',
    title: 'The Haldi Ceremony',
    marathiTitle: 'Halad Chadavne',
    significance: 'Turmeric paste is applied to the bride and groom to ward off evil spirits and provide a natural glow. It marks the beginning of the wedding rituals and signifies purification.',
    whatToWear: 'Yellow attire is traditional. Choose simple clothes (cotton kurtas or sundresses) that you do not mind getting stained with turmeric paste.',
    whatToExpect: 'A fun, messy, and high-energy event! Family members will smear turmeric paste on the couple (and often each other). Expect dhol (drums) and dancing.',
    imageUrl: 'https://cdn.shopify.com/s/files/1/1206/7410/files/C_J_-_Top_7_myths_of_Turmeric_debunked.jpg?v=1557222010'
  },
  {
    id: 'mehendi',
    title: 'The Mehendi',
    marathiTitle: 'Mehendi',
    significance: 'Henna is applied to the bride’s hands and feet in intricate designs. Folklore says the darker the henna stain, the more love the bride will receive from her husband and in-laws.',
    whatToWear: 'Colorful, comfortable clothing. Sleeveless or short sleeves are practical if you plan to get a small henna design done on your hands.',
    whatToExpect: 'A relaxed afternoon of art and music. Guests can get small henna designs applied by professional artists while enjoying snacks and music.',
    imageUrl: 'https://images.unsplash.com/photo-1505932794465-147d1f1b2c97?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'sangeet',
    title: 'The Sangeet',
    marathiTitle: 'Sangeet',
    significance: 'Literally translating to "Sung Together", this is a musical party designed to break the ice between the two families. It is a celebration of union through dance and song.',
    whatToWear: 'This is the time to sparkle! Glamorous Indian wear (Lehengas, Sherwanis) or formal Cocktail attire. Bring your dancing shoes.',
    whatToExpect: 'Choreographed dance performances by friends and family, followed by an open dance floor with a mix of Bollywood, Latin, and Pop hits.',
    imageUrl: 'https://i.ytimg.com/vi/Wy6CTfiQQgk/maxresdefault.jpg'
  },
  {
    id: 'wedding',
    title: 'The Wedding Ceremony',
    marathiTitle: 'Lagna',
    significance: 'The Maharashtrian wedding is known for its simplicity and sacred rituals. Key moments include the "Antarpat" (a silk curtain separating the couple) and the "Mangalashtak" (sacred verses chanted at the auspicious moment).',
    whatToWear: 'Traditional Indian Saree (Paithani styles are local to the region), Kurta Pajama, or a Formal Western Suit. Modest attire is appreciated for the ceremony.',
    whatToExpect: 'The couple wears "Mundavalya" (pearl strings on the forehead). Guests shower the couple with "Akshata" (unbroken rice) as blessings during the chanting. The ceremony is followed by a vegetarian feast.',
    imageUrl: 'https://images.unsplash.com/photo-1597157639073-69284dc0fdaf?q=80&w=800&auto=format&fit=crop'
  }
];

export const ATTIRE_GUIDE: AttireItem[] = [
  {
    id: 'lehenga',
    name: 'Lehenga Choli',
    pronunciation: 'Leh-hen-gah',
    gender: 'Women',
    description: 'A three-piece outfit consisting of a long, full skirt (Lehenga), a fitted blouse (Choli), and a scarf drape (Dupatta). They can be simple or heavily embroidered.',
    bestFor: ['Sangeet', 'Reception'],
    imageUrl: 'https://images.pexels.com/photos/27155546/pexels-photo-27155546.jpeg'
  },
  {
    id: 'saree',
    name: 'Saree',
    pronunciation: 'Saa-ree',
    gender: 'Women',
    description: 'A long drape of fabric (usually 6-9 yards) wrapped around the waist and draped over the shoulder, worn over a petticoat and a blouse. For our wedding, "Paithani" silk sarees are the local favorite.',
    bestFor: ['Wedding Ceremony', 'Reception'],
    imageUrl: 'https://images.pexels.com/photos/9418783/pexels-photo-9418783.jpeg'
  },
  {
    id: 'kurta',
    name: 'Kurta Pajama',
    pronunciation: 'Kur-ta Pa-ja-ma',
    gender: 'Men',
    description: 'A loose, collarless shirt (Kurta) falling below the knees, worn with lightweight trousers (Pajama). It is comfortable and perfect for daytime events.',
    bestFor: ['Haldi', 'Mehendi'],
    imageUrl: 'https://images.pexels.com/photos/13624147/pexels-photo-13624147.jpeg'
  },
  {
    id: 'sherwani',
    name: 'Sherwani',
    pronunciation: 'Sher-va-nee',
    gender: 'Men',
    description: 'A coat-like garment worn over a kurta, usually made of heavier fabric like silk or wool with lining. It is the equivalent of a tuxedo in Indian formal wear.',
    bestFor: ['Wedding Ceremony', 'Reception'],
    imageUrl: 'https://images.unsplash.com/photo-1610047402714-307d99a677db?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
  },
  {
    id: 'anarkali',
    name: 'Anarkali',
    pronunciation: 'Ah-nar-ka-lee',
    gender: 'Women',
    description: 'A long, frock-style top that flares out from the waist, worn with slim pants. It is essentially a very elegant dress and is comfortable for dancing.',
    bestFor: ['Sangeet', 'Mehendi'],
    imageUrl: 'https://images.cbazaar.com/images/faux-georgette-embroidered-anarkali-suit-slswe301032ra-u.jpg'
  },
  {
    id: 'bandhgala',
    name: 'Bandhgala / Jodhpuri',
    pronunciation: 'Band-ga-la',
    gender: 'Men',
    description: 'A formal evening suit featuring a coat with a standing collar (Nehru collar). It looks sharp, modern, and is a great alternative to a western suit.',
    bestFor: ['Sangeet', 'Reception'],
    imageUrl: 'https://www.anitadongre.com/dw/image/v2/BGCX_PRD/on/demandware.static/-/Sites-masterCatalog_AD_India/default/dwf402e75c/images/hires/F25/Men/F25MR53J_Green_1.jpg?sw=1400&sh=2100&sm=fit&strip=false'
  }
];

export const SYSTEM_INSTRUCTION = `
You are the "Wedding Assistant" for Pavitra and Ramon's wedding.
Your tone is warm, polite, helpful, and excited.
You are chatting with a wedding guest on the couple's wedding website.

Here are the specific details you must know and use to answer questions:
- Couple: ${WEDDING_DATA.couple.partner1} & ${WEDDING_DATA.couple.partner2}.
- Date: ${WEDDING_DATA.date}.
- Venue: ${WEDDING_DATA.location.venue} in ${WEDDING_DATA.location.city}.
- Story: ${WEDDING_DATA.story}
- Travel: ${WEDDING_DATA.travelInfo}
- Schedule: 
  1. Feb 02: Haldi & Mehendi at 11:00 AM (Taj The Trees).
  2. Feb 03: Vows & Sangeet at 5:00 PM (Taj The Trees).
  3. Feb 04: Wedding Ceremony & Reception at 4:30 PM (Taj The Trees).

- Customs: 
  - Haldi: Yellow clothes, messy turmeric fun.
  - Sangeet: Dancing, glitzy clothes.
  - Wedding (Lagna): Traditional Maharashtrian, pearl headgear (Mundavalya), throwing rice.

- Attire Guide:
  - Lehenga: Skirt + Blouse + Scarf (Women). Good for dancing.
  - Saree: Draped fabric (Women). Traditional.
  - Kurta: Long shirt (Men). Casual/Day.
  - Sherwani: Coat-like (Men). Formal/Wedding.

- Dress Code: Traditional Indian or Formal Western. Bright colors encouraged!
- Accommodation: We recommend staying at Taj The Trees, Mumbai.
- Registry: We are accepting Bitcoin (address on registry page) or donations to 'Educate Girls'.

If a guest asks a question not in this data, kindly ask them to email the wedding planner at planner@mumbaiweddings.com.
Do not make up facts not listed here.
Keep answers concise (under 3 sentences usually).
`;