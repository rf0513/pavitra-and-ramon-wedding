import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Heart } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Our Story', path: '/story' },
    { name: 'Traditions', path: '/traditions' },
    { name: 'Events', path: '/events' },
    { name: 'Registry', path: '/registry' },
  ];

  const navbarClasses = `fixed w-full z-50 transition-all duration-300 ${
    scrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-4' : 'bg-transparent py-6'
  }`;

  // Fix: Check if we are on the home page. 
  // If on Home page: Text is white when at top (transparent bg), dark when scrolled.
  // If on Other pages: Text is always dark (because background is cream/white).
  const isHome = location.pathname === '/';
  const useDarkText = scrolled || !isHome;

  const textClasses = useDarkText 
    ? 'text-wedding-charcoal' 
    : 'text-wedding-charcoal lg:text-white';
    
  const logoColor = useDarkText 
    ? 'text-wedding-rani' 
    : 'text-wedding-rani lg:text-white';
    
  const buttonColor = useDarkText
    ? 'text-wedding-rani'
    : 'text-wedding-rani lg:text-white';

  return (
    <nav className={navbarClasses}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-full">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className={`font-serif text-3xl tracking-widest font-bold ${logoColor}`}>
              P <span className="text-wedding-gold">&</span> R
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`text-sm uppercase tracking-widest hover:text-wedding-rani transition-colors font-semibold ${
                  location.pathname === link.path 
                    ? 'text-wedding-rani border-b-2 border-wedding-rani' 
                    : textClasses
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 focus:outline-none ${buttonColor}`}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg animate-fade-in-down border-t-4 border-wedding-rani">
          <div className="px-4 pt-2 pb-6 space-y-2 flex flex-col items-center">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="block px-3 py-3 text-base font-serif font-bold text-wedding-charcoal hover:text-wedding-rani"
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-4">
              <Heart className="text-wedding-rani" size={20} />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;