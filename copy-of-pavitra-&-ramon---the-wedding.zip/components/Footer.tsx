import React from 'react';
import { WEDDING_DATA } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-wedding-charcoal text-wedding-cream py-16 border-t-8 border-wedding-rani">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h2 className="font-serif text-4xl mb-4 text-wedding-gold">
          {WEDDING_DATA.couple.partner1} & {WEDDING_DATA.couple.partner2}
        </h2>
        <p className="font-sans text-sm tracking-[0.2em] uppercase mb-8 text-wedding-marigold font-bold">
          {WEDDING_DATA.date} • {WEDDING_DATA.location.city}
        </p>
        <div className="flex justify-center items-center gap-4 mb-8">
           <div className="w-12 h-px bg-wedding-gold"></div>
           <div className="text-wedding-rani text-xl">❤</div>
           <div className="w-12 h-px bg-wedding-gold"></div>
        </div>
        <p className="text-xs text-gray-400">
          See you in Mumbai!
        </p>
      </div>
    </footer>
  );
};

export default Footer;