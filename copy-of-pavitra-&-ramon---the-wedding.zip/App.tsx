import React from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Story from './pages/Story';
import Events from './pages/Events';
import Registry from './pages/Registry';
import Traditions from './pages/Traditions';
import WeddingAssistant from './components/WeddingAssistant';

// Scroll to top wrapper
const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <ScrollToTop />
      <div className="font-sans text-wedding-charcoal antialiased selection:bg-wedding-gold selection:text-white">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/story" element={<Story />} />
            <Route path="/traditions" element={<Traditions />} />
            <Route path="/events" element={<Events />} />
            <Route path="/registry" element={<Registry />} />
          </Routes>
        </main>
        <Footer />
        <WeddingAssistant />
      </div>
    </HashRouter>
  );
};

export default App;