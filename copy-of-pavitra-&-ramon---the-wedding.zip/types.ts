export interface WeddingEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  address: string;
  description: string;
  iconName: 'ring' | 'cheers' | 'party' | 'utensils';
}

export interface RegistryItem {
  id: string;
  store: string;
  link: string;
  description: string;
  imageUrl: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface WeddingCustom {
  id: string;
  title: string;
  marathiTitle?: string;
  significance: string;
  whatToWear: string;
  whatToExpect: string;
  imageUrl: string;
}

export interface AttireItem {
  id: string;
  name: string;
  pronunciation?: string;
  description: string;
  gender: 'Women' | 'Men' | 'Unisex';
  bestFor: string[];
  imageUrl: string;
}

export interface RSVPFormData {
  firstName: string;
  lastName: string;
  email: string;
  attending: string;
  guests: number | string;
  dietaryRestrictions: string;
}